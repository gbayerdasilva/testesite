INSTALLATION
============

Install using PMDG Livery Mangager.

1. unzip the .ptp file to a folder at your choice.

2. open the PMDG livery-manager (FSX/P3D-location\PMDG\Livery Manager)

3. choose in the "Installed Aircraft Variants" window "800NGX WL"

4. click the "Select Livery to Install" button.

5. navigate to the folder with your unzipped *.ptp file and doubleclick it.

6. fly!

===========

For contact info write us at:

request.hangar226@gmail.com

don't forget to visit

http://elmikey.wix.com/hangar226 

for future releases!
